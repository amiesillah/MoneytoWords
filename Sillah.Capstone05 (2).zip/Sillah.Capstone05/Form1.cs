﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sillah.Capstone05
{
    public partial class frmMoney : Form
    {
        public frmMoney()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void txtInput_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnConvert_Click(object sender, EventArgs e)
        {
            String input = txtInput.Text;

            if (Double.Parse(input) > 1000000000)
            {
                MessageBox.Show("Number must be less than 1 billion");
                return;
            }
                

            string[] splitString = input.Split('.');

            string[] dollarString = new string[splitString[0].Length];

            string[] centString = new string[splitString[1].Length];

            string word = "";
            string word1 = "";
            string word2 = "";
            string word3 = "";
            string word4 = "";
            string word5 = "";
            string word6 = "";
            string word7 = "";
            string word8 = "";
            string word9 = "";
            string word10 = "";
            string word11 = "";
            string word12 = "";

            for (int i = splitString[0].Length - 1; i >= 0; i--)
            {
                char c = splitString[0][i];

                if (i == splitString[0].Length - 1)
                {
                    word = GetWord(c);
                    word1 = word;
                }
                else if (i == splitString[0].Length - 2)
                {
                    word2 = GetSecondPlaceWord(c, splitString[0][splitString[0].Length - 1]);

                    if (c == '1')
                        word1 = "";
                }
                else if (i == splitString[0].Length - 3)
                {
                    word = GetWord(c);

                    if (word.Length > 1)

                        word3 = word + " hundred ";

                }
                else if (i == splitString[0].Length - 4)
                {

                    word = GetWord(c);

                    if (word.Length > 1)

                        word4 = word + " thousand ";

                }
                else if (i == splitString[0].Length - 5)
                {
                    word5 = GetSecondPlaceWord(c, splitString[0][splitString[0].Length - 4]);

                    if (c == '1')
                        word4 = "thousand ";
                }
                else if (i == splitString[0].Length - 6)
                {
                    word = GetWord(c);
                    if (word.Length > 1)

                        word6 = word + " hundred ";


                }
                else if (i == splitString[0].Length - 7)
                {
                    word = GetWord(c);
                    if (word.Length > 1)

                        word7 = word + " million ";


                }
                else if (i == splitString[0].Length - 8)
                {
                    word8 = GetSecondPlaceWord(c, splitString[0][splitString[0].Length - 7]);
                    if (c == '1')
                        word7 = "million ";
                }
                else if (i == splitString[0].Length - 9)
                {
                    word = GetWord(c);
                    if (word.Length > 1)

                        word9 = word + " hundred ";


                }
                else if (i == splitString[0].Length - 10)
                {
                    word = GetWord(c);
                    if (word.Length > 1)

                        word10 = word + " billion ";


                }

            }
            for (int i = splitString[1].Length - 1; i >= 0; i--)
            {
                char c = splitString[1][i];

                if (i == splitString[1].Length - 1)
                {
                    word = GetWord(c);
                    word11 = word;
                }
                else if (i == splitString[1].Length - 2)
                {
                    word12 = GetSecondPlaceWord(c, splitString[1][splitString[1].Length - 1]);

                    if (c == '1')
                        word11 = "";
                }
            }

            txtResult.Text = word10 + word9 + word8 + word7 + word6
                + word5 + word4 + word3 + word2 + word1 + " dollars and " + word12 + word11 + " cents";

        }
        private string GetWord(char c)
        {
            string word = "";
            if (c == '0')
                word = " ";
            else if (c == '1')
                word = "one";

            else if (c == '2')
                word = "two";

            else if (c == '3')
                word = "three";

            else if (c == '4')
                word = "four";

            else if (c == '5')
                word = "five";

            else if (c == '6')
                word = "six";

            else if (c == '7')
                word = "seven";

            else if (c == '8')
                word = "eight";

            else if (c == '9')
                word = "nine";

            return word;
        }

        private string GetSecondPlaceWord(char c, char otherNumber)
        {
            string word = "";
            if (c == '0')
                word = "";

            else if (c == '1')
            {
                if (otherNumber == '1')
                    word = "eleven ";

                else if (otherNumber == '2')
                    word = "twelve ";

                else if (otherNumber == '3')
                    word = "thirteen ";

                else if (otherNumber == '4')
                    word = "fourteen ";

                else if (otherNumber == '5')
                    word = "fifthteen ";

                else if (otherNumber == '6')
                    word = "sixteen ";

                else if (otherNumber == '7')
                    word = "seventeen ";

                else if (otherNumber == '8')
                    word = "eighteen ";

                else if (otherNumber == '9')
                    word = "nineteen ";

            }


            else if (c == '2')
                word = "twenty ";

            else if (c == '3')
                word = "thirty ";

            else if (c == '4')
                word = "fourty ";

            else if (c == '5')
                word = "fifty ";

            else if (c == '6')
                word = "sixty ";

            else if (c == '7')
                word = "seventy ";

            else if (c == '8')
                word = "eighty ";

            else if (c == '9')
                word = "ninety ";

            return word;
        }

        private void lblDollar_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void txtResult_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            txtInput.Text = "";
        }
    }
}
